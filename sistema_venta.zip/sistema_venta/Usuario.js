class Usuario {
    constructor(id, nombre, rol) {
        this.id = id;
        this.nombre = nombre;
        this.rol = rol;
    }

    esAdmin() {
        return this.rol === 'admin';
    }

    toString() {
        return `[Usuario] ${this.nombre} | ${this.rol}`;
    }

    static async login(nombre, password) {
        const datos = new FormData();
        datos.append('accion', 'login');
        datos.append('nombre', nombre);
        datos.append('password', password);
        const res = await fetch('api.php', { method: 'POST', body: datos });
        return await res.json();
    }

    static async registrar(nombre, password) {
        const datos = new FormData();
        datos.append('accion', 'registrar_usuario');
        datos.append('nombre', nombre);
        datos.append('password', password);
        const res = await fetch('api.php', { method: 'POST', body: datos });
        return await res.json();
    }

    static guardarSesion(id, nombre, rol) {
        localStorage.setItem('userId', id);
        localStorage.setItem('userName', nombre);
        localStorage.setItem('userRol', rol);
    }

    static obtenerSesion() {
        return {
            id:     localStorage.getItem('userId'),
            nombre: localStorage.getItem('userName'),
            rol:    localStorage.getItem('userRol')
        };
    }

    static cerrarSesion() {
        localStorage.clear();
        window.location.href = 'index.html';
    }
}