const UI = {
    mostrarMensaje(texto, tipo) {
        tipo = tipo || 'ok';
        const msg = document.getElementById('mensaje');
        if (!msg) return;
        msg.textContent = texto;
        msg.className = (tipo === 'ok') ? 'msg-ok' : 'msg-error';
        msg.style.display = 'block';
        setTimeout(() => { msg.style.display = 'none'; }, 3500);
    },

    llenarSelect(selectId, lista) {
        const select = document.getElementById(selectId);
        if (!select) return;
        select.innerHTML = '<option value="">-- Selecciona --</option>';
        lista.aArreglo().forEach(item => {
            const op = document.createElement('option');
            op.value = item.id;
            op.textContent = item.nombre;
            select.appendChild(op);
        });
    },

    mostrarTablaProductos(lista, contenedorId, esAdmin) {
        esAdmin = esAdmin || false;
        const contenedor = document.getElementById(contenedorId);
        if (!contenedor) return;
        const arreglo = lista.aArreglo();
        if (arreglo.length === 0) {
            contenedor.innerHTML = '<p class="sin-datos">No hay productos.</p>';
            return;
        }
        let html = '<table><thead><tr><th>Nombre</th><th>Precio</th><th>Stock</th><th>Categoria</th><th>Proveedor</th></tr></thead><tbody>';
        arreglo.forEach(p => {
            const cls = p.stock == 0 ? ' class="agotado"' : '';
            html += `<tr${cls}>
                <td>${p.nombre}</td>
                <td>$${parseFloat(p.precio).toFixed(2)}</td>
                <td>${p.stock == 0 ? 'AGOTADO' : p.stock}</td>
                <td>${p.categoria || '-'}</td>
                <td>${p.proveedor || '-'}</td>
            </tr>`;
        });
        html += '</tbody></table>';
        contenedor.innerHTML = html;
    },

    mostrarTablaCompras(lista, contenedorId) {
        const contenedor = document.getElementById(contenedorId);
        if (!contenedor) return;
        const arreglo = lista.aArreglo();
        if (arreglo.length === 0) {
            contenedor.innerHTML = '<p class="sin-datos">No hay ventas registradas.</p>';
            return;
        }
        let html = '<table><thead><tr><th>Usuario</th><th>Producto</th><th>Cantidad</th><th>Total</th><th>Fecha</th></tr></thead><tbody>';
        arreglo.forEach(c => {
            html += `<tr>
                <td>${c.usuario}</td>
                <td>${c.producto}</td>
                <td>${c.cantidad}</td>
                <td>$${parseFloat(c.total).toFixed(2)}</td>
                <td>${c.fecha}</td>
            </tr>`;
        });
        html += '</tbody></table>';
        contenedor.innerHTML = html;
    },

    mostrarTablaSimple(lista, contenedorId, columnas) {
        const contenedor = document.getElementById(contenedorId);
        if (!contenedor) return;
        const arreglo = lista.aArreglo();
        if (arreglo.length === 0) {
            contenedor.innerHTML = '<p class="sin-datos">No hay registros.</p>';
            return;
        }
        let html = '<table><thead><tr>';
        columnas.forEach(c => { html += `<th>${c.titulo}</th>`; });
        html += '</tr></thead><tbody>';
        arreglo.forEach(item => {
            html += '<tr>';
            columnas.forEach(c => { html += `<td>${item[c.campo] !== undefined ? item[c.campo] : '-'}</td>`; });
            html += '</tr>';
        });
        html += '</tbody></table>';
        contenedor.innerHTML = html;
    }
};

const MostrarUI = UI;