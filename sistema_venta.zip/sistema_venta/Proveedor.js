class CrearProveedor extends Entidad {

    constructor(id, nombre, telefono, direccion) {
        super(id, nombre);
        this.telefono  = telefono;
    
        this.direccion = direccion;
   
 }

  toString() {
    return `[Proveedor] ${this.nombre}`;
    }
}


const Proveedor = {

   async listar() {
      
    const res = await fetch('api.php?accion=listar_proveedores');
        const datos = await res.json();
      
        const lista = new ListaEnlazada();
 datos.forEach(p => lista.agregar(new CrearProveedor(p.id,  p.nombre, p.telefono, p.direccion)));
      return lista;
    },

    async crear(nombre, telefono, direccion) {
        const datos = new FormData();
        datos.append('accion',    'crear_proveedor');
        datos.append('nombre',    nombre);
        datos.append('telefono', telefono  || '');
        datos.append('direccion', direccion || '');
        const res = await fetch('api.php', {method: 'POST', body: datos});
        return await res.json();
    },

    async editar(id, nombre, telefono, direccion) {
        const datos = new FormData();
        datos.append('accion',    'editar_proveedor');
        datos.append('id',id);
        datos.append('nombre',  nombre);
        datos.append('telefono',  telefono  || '');
        datos.append('direccion', direccion || '');
        const res = await fetch('api.php', { method: 'POST', body: datos });
        return await res.json();
    },

    async eliminar(id) {
        const datos = new FormData();
        datos.append('accion', 'eliminar_proveedor');
        datos.append('id', id);
        const res = await fetch('api.php', {method: 'POST', body: datos});
        return await res.json();
    }
};