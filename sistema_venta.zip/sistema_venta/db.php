<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Content-Type: application/json");


$host     = "localhost";
$usuario  = "root";

$password = "";
$base     = "sistema_venta";

$conn = new mysqli($host, $usuario, $password, $base);

if ($conn->connect_error) {


    die(json_encode(["error" => "No se pudo conectar: " . $conn->connect_error]));
}



$conn->set_charset("utf8");
?>