class CrearCategoria extends Entidad {
   
    constructor(id, nombre, descripcion) {
     
        super(id, nombre);
        this.descripcion = descripcion;
    }
  toString() {
        return `[Categoria] ${this.nombre}`;
    }
}
const Categoria = {

    async listar() {
    
        const res = await fetch('api.php?accion=listar_categorias');
        const datos = await res.json();

        const lista = new ListaEnlazada();
        datos.forEach(c => lista.agregar(new CrearCategoria(c.id, c.nombre, c.descripcion)));
        return lista;
    },

   
    async crear(nombre, descripcion) {
        const datos = new FormData();

        datos.append('accion', 'crear_categoria');
        datos.append('nombre', nombre);

          datos.append('descripcion', descripcion || '');
           const res = await fetch ('api.php', { method:'POST', body: datos });
     return await res.json();

    },

    async editar(id, nombre, descripcion) {

        const datos = new FormData();
        datos.append('accion',      'editar_categoria');
        datos.append('id', id);

        datos.append('nombre', nombre);

        datos.append('descripcion', descripcion || '');
        const res = await fetch('api.php', {method: 'POST', body: datos});
        return await res.json();
    },

    async eliminar(id) {
        const datos = new FormData();

        datos.append('accion',  'eliminar_categoria');
        datos.append('id', id);

        const res = await fetch('api.php',   { method: 'POST', body: datos });
        return await  res.json();

    }

};