class CrearProducto extends Entidad {
    constructor(id, nombre, precio, stock, imagen, id_categoria, id_proveedor, categoria, proveedor) {
        super(id, nombre);
        this.precio    = precio;
        this.stock     = stock;
        this.imagen       = imagen || "";
        this.id_categoria = id_categoria;
        this.id_proveedor = id_proveedor;
        this.categoria = categoria;
        this.proveedor = proveedor;
    }

    tieneStock() {
        return this.stock > 0;
    }

    toString() {
        return `[Producto] ${this.nombre} | $${this.precio}`;
    }

    static async obtenerDisponibles() {
        const res   = await fetch('api.php?accion=listar_productos');
        const datos = await res.json();
        const lista = new ListaEnlazada();
        datos.forEach(p => lista.agregar(new CrearProducto(p.id, p.nombre, p.precio, p.stock, p.imagen, p.id_categoria, p.id_proveedor, p.categoria, p.proveedor)));
        return lista;
    }
}


const Producto = {

    async listarAdmin() {
        const res   = await fetch('api.php?accion=listar_productos_admin');
        const datos = await res.json();
        const lista = new ListaEnlazada();
        datos.forEach(p => lista.agregar(new CrearProducto(p.id, p.nombre, p.precio, p.stock, p.imagen, p.id_categoria, p.id_proveedor, p.categoria, p.proveedor)));
        return lista;
    },

    async crear(nombre, precio, stock, imagen, idCategoria, idProveedor) {
        const datos = new FormData();
        datos.append('accion',       'crear_producto');
        datos.append('nombre',       nombre);
        datos.append('precio',       precio);
        datos.append('stock',        stock);
        datos.append('imagen', imagen || '');
        datos.append('id_categoria', idCategoria);
        datos.append('id_proveedor', idProveedor);
        const res = await fetch('api.php', { method: 'POST', body: datos });
        return await res.json();
    },

    async editar(id, nombre, precio, stock, imagen, idCategoria, idProveedor) {
        const datos = new FormData();
      
        datos.append('accion',       'editar_producto');
        datos.append('id',           id);
      
        datos.append('nombre',       nombre);
        datos.append('precio',       precio);
     
        datos.append('stock',        stock);
        datos.append('imagen', imagen || '');
     
        datos.append('id_categoria', idCategoria);
      
        datos.append('id_proveedor', idProveedor);
        const res = await fetch('api.php', { method: 'POST', body: datos });
        return await res.json();
    },

    async eliminar(id) {
        const datos = new FormData();
        datos.append('accion', 'eliminar_producto');
        datos.append('id',     id);
        const res = await fetch('api.php', { method: 'POST', body: datos });
        return await res.json();
    }

};