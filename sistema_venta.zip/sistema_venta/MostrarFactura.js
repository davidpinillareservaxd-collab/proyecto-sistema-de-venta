class MostrarFactura {

    constructor(usuario, producto, cantidad, precio, fecha) {

        this.usuario = usuario
        this.producto = producto
        this.cantidad = cantidad
        this.precio = precio
        this.fecha = fecha
        this.total = cantidad * precio

    }

    calcularTotal() {

        return this.cantidad * this.precio

    }

    toString() {

        return `Factura: ${this.usuario} compro ${this.cantidad} x ${this.producto}`

    }

    generarHTML() {

        const ahora = new Date()

        const fechaFormato = ahora.toLocaleDateString("es-CO", {
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit"
        })

        const subtotal = this.calcularTotal()

        return `
            <div class="factura-cuerpo">

                <div class="factura-header">
                    <div class="factura-logo">🛒</div>
                    <h2>Sistema de Venta</h2>
                    <p>Comprobante de compra</p>
                </div>

                <div class="factura-linea"></div>

                <div class="factura-dato">
                    <span>Cliente</span>
                    <strong>${this.usuario}</strong>
                </div>

                <div class="factura-dato">
                    <span>Fecha</span>
                    <strong>${fechaFormato}</strong>
                </div>

                <div class="factura-linea"></div>

                <div class="factura-dato">
                    <span>Producto</span>
                    <strong>${this.producto}</strong>
                </div>

                <div class="factura-dato">
                    <span>Precio unitario</span>
                    <strong>$${parseFloat(this.precio).toFixed(2)}</strong>
                </div>

                <div class="factura-dato">
                    <span>Cantidad</span>
                    <strong>${this.cantidad}</strong>
                </div>

                <div class="factura-linea"></div>

                <div class="factura-total">
                    <span>TOTAL</span>
                    <strong>$${parseFloat(subtotal).toFixed(2)}</strong>
                </div>

                <div class="factura-pie">
                    Gracias por tu compra 🎉
                </div>

            </div>
        `

    }

    mostrarEnModal() {

        const contenedor = document.getElementById("factura-overlay")

        if (contenedor) {
            contenedor.innerHTML = `
                <div class="factura-modal">
                    ${this.generarHTML()}
                    <button class="factura-cerrar" onclick="document.getElementById('factura-overlay').innerHTML=''; document.getElementById('factura-overlay').style.display='none';">CERRAR</button>
                </div>
            `
            contenedor.style.display = "flex"
        }

    }

    static mostrar(usuario, producto, cantidad, precio) {

        const factura = new MostrarFactura(usuario, producto, cantidad, precio, new Date())

        factura.mostrarEnModal()

    }

    static cerrar() {

        const modal = document.getElementById("factura-overlay")

        if (modal) {
            modal.innerHTML = ""
            modal.style.display = "none"
        }

    }

}