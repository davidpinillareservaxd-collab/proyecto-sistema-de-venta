class RealizarCompra {
    constructor(idUsuario, idProducto, cantidad) {
        this.idUsuario  = idUsuario;
        this.idProducto = idProducto;
        this.cantidad   = cantidad;
    }

    async procesar() {
        const datos = new FormData();
        datos.append('accion', 'comprar');
        datos.append('id_usuario', this.idUsuario);
        datos.append('id_producto', this.idProducto);
        datos.append('cantidad', this.cantidad);
        const res = await fetch('api.php', { method: 'POST', body: datos });
        return await res.json();
    }

    static async misCompras(idUsuario) {
        const res = await fetch('api.php?accion=mis_compras&id_usuario=' + idUsuario);
        const datos = await res.json();
        const lista = new ListaEnlazada();
        datos.forEach(c => lista.agregar(c));
        return lista;
    }
}

const Compra = {
    async listarTodas() {
        const res = await fetch('api.php?accion=listar_compras');
        const datos = await res.json();
        const lista = new ListaEnlazada();
        datos.forEach(c => lista.agregar(c));
        return lista;
    }
};