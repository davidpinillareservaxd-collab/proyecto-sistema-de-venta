CREATE DATABASE IF NOT EXISTS sistema_venta;

USE sistema_venta;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,

      nombre VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,

       rol ENUM('admin', 'usuario') DEFAULT 'usuario',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP


);

   
   CREATE TABLE IF NOT EXISTS categorias (
   
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,

    descripcion TEXT
);

    CREATE TABLE IF NOT EXISTS proveedores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,

telefono VARCHAR(20),
    direccion VARCHAR(200)
);

     CREATE TABLE IF NOT EXISTS productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
        nombre VARCHAR(100) NOT NULL,
             precio DECIMAL(10,2) NOT NULL,
      stock INT DEFAULT 0,
               imagen LONGTEXT,
                id_categoria INT,
              id_proveedor INT,

FOREIGN KEY (id_categoria) REFERENCES categorias(id),


 FOREIGN KEY (id_proveedor) REFERENCES proveedores(id)
);

CREATE TABLE IF NOT EXISTS compras (

  id INT AUTO_INCREMENT PRIMARY KEY,
       id_usuario INT,
  id_producto INT,

    cantidad INT NOT NULL,
    total DECIMAL(10,2) NOT NULL,

    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
       FOREIGN KEY (id_usuario) REFERENCES usuarios(id),
 
    FOREIGN KEY (id_producto) REFERENCES productos(id)
);

   
    INSERT INTO usuarios(nombre, password,  rol)  VALUES  ('admin',  'admin123',  'admin') ;