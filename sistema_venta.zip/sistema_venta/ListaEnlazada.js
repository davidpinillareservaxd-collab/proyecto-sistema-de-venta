class ListaEnlazada {
   
    constructor() {
       
        this.cabeza = null;
       
        this.tamaño = 0;
    }

agregar(dato) {
        const nodo = new Nodo(dato);
          if (!this.cabeza) {
            this.cabeza = nodo;
        
        } else {
            let actual = this.cabeza;
    while (actual.siguiente) actual = actual.siguiente;
            actual.siguiente = nodo;
        }
      this.tamaño++;
    }

     aArreglo() {
        const arr = [];
        let actual = this.cabeza;
        while (actual) {
            arr.push(actual.dato);
            actual = actual.siguiente;
        }
        return arr;
    }

 buscarPorId(id) {
      let actual = this.cabeza;
      while (actual) {
        if (actual.dato.id == id) return actual.dato;
    actual = actual.siguiente;
      }
  return null;
    }
}