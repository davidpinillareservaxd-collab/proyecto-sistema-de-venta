<?php
require_once "db.php";


$accion = $_GET["accion"] ?? $_POST["accion"] ?? "";


     if ($accion === "login") {
       $nombre   = $_POST["nombre"];
       $password = $_POST["password"];
        $sql      = "SELECT * FROM usuarios WHERE nombre='$nombre' AND password='$password'";
        $res      = $conn->query($sql);
        
        if ($res->num_rows > 0) {
           $user = $res->fetch_assoc();
            echo json_encode(["ok" => true, "rol" => $user["rol"], "id" => $user["id"], "nombre" => $user["nombre"]]);
       
            } else {
                echo json_encode(["ok" => false, "mensaje" => "Usuario o contraseña incorrectos"]);
         }
}

   if($accion === "registrar_usuario") {
      $nombre   = $_POST["nombre"];
   $password = $_POST["password"] ;
      $check    = $conn->query("SELECT id FROM usuarios WHERE nombre='$nombre'")   ;
    if ($check->num_rows > 0) {
              echo json_encode(["ok" => false, "mensaje" => "El usuario ya existe"]);
    } else {
        $sql = "INSERT INTO usuarios (nombre, password, rol) VALUES ('$nombre', '$password', 'usuario')";
        echo $conn->query($sql) ? json_encode(["ok" => true]) : json_encode(["ok" => false, "mensaje" => "Error al registrar"]);
    }
}


if   ($accion === "crear_categoria") {
    $nombre      = $_POST["nombre"];
      $descripcion = $_POST["descripcion"];
 $sql = "INSERT INTO categorias (nombre, descripcion) VALUES ('$nombre', '$descripcion')";
    echo $conn->query($sql) ? json_encode(["ok" => true]) : json_encode(["ok" => false]);
}

if   ($accion === "listar_categorias") {
    $res   = $conn->query("SELECT * FROM categorias");
       $lista = [];
       while ($fila = $res->fetch_assoc()) $lista[] = $fila;
    echo json_encode($lista);
}

if    ($accion === "editar_categoria") {
      $id          = $_POST["id"];
   
      $nombre      = $_POST["nombre"];
       $descripcion = $_POST["descripcion"];
    $sql = "UPDATE categorias SET nombre='$nombre', descripcion='$descripcion' WHERE id='$id'";
    echo $conn->query($sql) ? json_encode(["ok" => true]) : json_encode(["ok" => false]);
}

if   ($accion === "eliminar_categoria") {
    
$id  = $_POST["id"];
       $sql = "DELETE FROM categorias WHERE id='$id'";
       echo $conn->query($sql) ? json_encode(["ok" => true]) : json_encode(["ok" => false]);
} 


if    ($accion === "crear_proveedor") {
    $nombre    = $_POST["nombre"];
      $telefono  = $_POST["telefono"];
    $direccion = $_POST["direccion"];
      $sql = "INSERT INTO proveedores (nombre, telefono, direccion) VALUES ('$nombre', '$telefono', '$direccion')";
      
      echo $conn->query($sql) ? json_encode(["ok" => true]) : json_encode(["ok" => false]);
}

if    ($accion === "listar_proveedores") {
    $res   = $conn->query("SELECT * FROM proveedores");
       $lista = [];
    while ($fila = $res->fetch_assoc()) $lista[] = $fila;
   
    echo json_encode($lista);
}

if ($accion === "editar_proveedor") {
    $id        = $_POST["id"];
    $nombre    = $_POST["nombre"];
    $telefono  = $_POST["telefono"];
    $direccion = $_POST["direccion"];
    $sql = "UPDATE proveedores SET nombre='$nombre', telefono='$telefono', direccion='$direccion' WHERE id='$id'";
    
    echo $conn->query($sql) ? json_encode(["ok" => true]) : json_encode(["ok" => false]) ;
}

if ($accion === "eliminar_proveedor") {
    $id  = $_POST["id"];
    $sql = "DELETE FROM proveedores WHERE id='$id'";
    
    echo $conn->query($sql) ? json_encode(["ok" => true]) : json_encode(["ok" => false])  ;
}


   if ($accion === "crear_producto") {
     $nombre  = $_POST["nombre"];
    $precio  = $_POST["precio"];
     $stock   = $_POST["stock"];
    $id_cat  = $_POST["id_categoria"];
     $id_prov = $_POST["id_proveedor"];

       $imagen  = $_POST["imagen"] ?? "";

     $sql = "INSERT INTO productos (nombre, precio, stock, imagen, id_categoria, id_proveedor) 
             VALUES ('$nombre', '$precio', '$stock', '$imagen', '$id_cat', '$id_prov')";
    
     echo $conn->query($sql) ? json_encode(["ok" => true]) : json_encode(["ok" => false]);
}

if ($accion === "listar_productos") {
    $sql = "SELECT p.*, c.nombre AS categoria, v.nombre AS proveedor
            FROM productos p
            LEFT JOIN categorias  c ON p.id_categoria = c.id
            LEFT JOIN proveedores v ON p.id_proveedor  = v.id
            WHERE p.stock > 0";
    $res   = $conn->query($sql);
    $lista = [];
   
    while ($fila = $res->fetch_assoc()) $lista[] = $fila;
    echo json_encode($lista);
}

if ($accion === "listar_productos_admin") {
    $sql = "SELECT p.*, c.nombre AS categoria, v.nombre AS proveedor
            FROM productos p
            LEFT JOIN categorias  c ON p.id_categoria = c.id
            LEFT JOIN proveedores v ON p.id_proveedor  = v.id";
  
  $res   = $conn->query($sql);
    $lista = [];
    while ($fila = $res->fetch_assoc()) $lista[] = $fila;
    echo json_encode($lista);
}

    if ($accion === "editar_producto") {
     $id      = $_POST["id"];
      $nombre  = $_POST["nombre"];
      $precio  = $_POST["precio"];
       $stock   = $_POST["stock"];
    $id_cat  = $_POST["id_categoria"];
      $id_prov = $_POST["id_proveedor"];

        $imagen  = $_POST["imagen"] ?? "";
        
        if ($imagen !== "") {
       $sql = "UPDATE productos SET nombre='$nombre', precio='$precio', stock='$stock',
               imagen='$imagen', id_categoria='$id_cat', id_proveedor='$id_prov' 
               WHERE id='$id'";
          } else {
       $sql = "UPDATE productos SET nombre='$nombre', precio='$precio', stock='$stock',
               id_categoria='$id_cat', id_proveedor='$id_prov' WHERE id='$id'";
          }

       echo $conn->query($sql) ? json_encode(["ok" => true]) : json_encode(["ok" => false]);
}

   if ($accion === "eliminar_producto") {
    $id  = $_POST["id"];
    $sql = "DELETE FROM productos WHERE id='$id'";
    echo $conn->query($sql) ? json_encode(["ok" => true]) : json_encode(["ok" => false]);
}


     if ($accion === "comprar") {
    $id_usuario  = $_POST["id_usuario"];
      $id_producto = $_POST["id_producto"];
    $cantidad    = $_POST["cantidad"];
    $prod        = $conn->query("SELECT * FROM productos WHERE id='$id_producto'")->fetch_assoc();

             if (!$prod) {
                     echo json_encode(["ok" => false, "mensaje" => "Producto no encontrado"]); 
                     } elseif ($prod["stock"] < $cantidad) {
        echo json_encode(["ok" => false, "mensaje" => "Stock insuficiente"]);
  } else {
      $total      = $prod["precio"] * $cantidad;
         $nuevoStock = $prod["stock"] - $cantidad;
     $conn->query("INSERT INTO compras (id_usuario, id_producto, cantidad, total) 
                   VALUES ('$id_usuario', '$id_producto', '$cantidad', '$total')");
        $conn->query("UPDATE productos SET stock='$nuevoStock' WHERE id='$id_producto'");
        
        $usuarioQuery = $conn->query("SELECT nombre FROM usuarios WHERE id='$id_usuario'")->fetch_assoc();
        
     echo json_encode([
         "ok" => true,
         "mensaje" => "Compra realizada con éxito",
         "factura" => [
             "usuario"  => $usuarioQuery["nombre"],
             "producto" => $prod["nombre"],
             "cantidad" => $cantidad,
             "precio"   => $prod["precio"],
             "total"    => $total,
             "fecha"    => date("Y-m-d H:i:s")
         ]
     ]);
    }
}

  if ($accion === "listar_compras") {
     $sql = "SELECT c.*, u.nombre AS usuario, p.nombre AS producto
             FROM compras c
              LEFT JOIN usuarios  u ON c.id_usuario  = u.id
               LEFT JOIN productos p ON c.id_producto = p.id
                ORDER BY c.fecha DESC";
                    $res   = $conn->query($sql);
                   $lista = [];
       while ($fila = $res->fetch_assoc()) $lista[] = $fila;
    echo json_encode($lista);
}

if   ($accion === "mis_compras") {
    $id_usuario = $_GET["id_usuario"] ?? 0;
    $sql = "SELECT c.*, p.nombre AS producto
            FROM compras c
            LEFT JOIN productos p ON c.id_producto = p.id
            WHERE c.id_usuario = '$id_usuario'
            ORDER BY c.fecha DESC";
    $res   = $conn->query($sql);
    $lista = [];
       while ($fila = $res->fetch_assoc()) $lista[] = $fila;
      echo json_encode($lista);
}



$conn->close();
?>