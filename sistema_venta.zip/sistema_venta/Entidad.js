class Entidad {
    constructor(id, nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    toString() {   return `[Entidad] ${this.nombre}`;
    }
}